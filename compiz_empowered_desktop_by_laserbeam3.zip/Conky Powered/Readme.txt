Here you go, my conky configs.

Apart from standard conky features, these configs use 2 external applications and one script:

- conkyRhythmbox - follow the instructions here to install
http://ubuntuforums.org/showthread.php?p=5843297

- conkyForecast - again, follow the instructions
http://ubuntuforums.org/showthread.php?t=869328
You will have to edit some files I didn't give you. Don't worry, you'll get them when you install this

- gmail script:
just copy the scripts folder to your home folder
you also have to replace <username> and <pass> from gmail.pl (found in that scripts folder) whith your corresponding gmail username and password

Place the fonts in /usr/share/fonts/truetype (you need root access for this)

Copy the .conky folder to your home folder

Copy conky_start from the bin folder to /usr/bin or /usr/local/bin (again you need root access) and then add conky_start command to your startup sequence
